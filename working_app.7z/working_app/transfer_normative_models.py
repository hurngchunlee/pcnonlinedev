# -*- coding: utf-8 -*-
"""
Created on Fri May 13 14:23:33 2022

@author: piebar
"""

def transfer_normative_model(data_type, algorithm):
    from apply_normative_models_app import apply_normative_model
    from transfer_hbr_models import transfer_hbr_models